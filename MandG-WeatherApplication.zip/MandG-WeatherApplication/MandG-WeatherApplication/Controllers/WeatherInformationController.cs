﻿using MandG_WeatherApplication_Middleware.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace MandG_WeatherApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WeatherInformationController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IWeatherInformationMiddleware _middleware;
        public WeatherInformationController(IConfiguration configuration, IWeatherInformationMiddleware weatherInformationMiddleware)
        {
            _configuration = configuration;
            _middleware = weatherInformationMiddleware;
        }

        [HttpPost("WeatherInformation")]
        public async Task<IActionResult> WeatherInformation(IFormFile fileUpload)
        {
            if (fileUpload != null)
            {
                string fileData;

                using (StreamReader streamReader = new StreamReader(fileUpload.OpenReadStream()))
                {
                    fileData = streamReader.ReadToEnd();
                }

                var result = await _middleware.GetWeatherInformationForCities(fileData);
                return Ok(result);
            }
            return BadRequest("File not found");
        }
    }
}
