﻿namespace MandG_WeatherApplication.Models
{
    public class FileUpload
    {
        public IFormFile formFile { get; set; }
    }
}
