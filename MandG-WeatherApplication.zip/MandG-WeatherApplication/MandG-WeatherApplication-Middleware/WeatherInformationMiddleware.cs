﻿using MandG_WeatherApplication_ExternalResources.Interfaces;
using MandG_WeatherApplication_Middleware.Dtos;
using MandG_WeatherApplication_Middleware.Interfaces;

namespace MandG_WeatherApplication_Middleware
{
    public class WeatherInformationMiddleware : IWeatherInformationMiddleware
    {
        private readonly ICityFileRead _cityFileRead;
        private readonly IWeatherAPIExternal _weatherAPIExternal;
        private readonly ICityFileWrite _cityFileWrite;
        public WeatherInformationMiddleware(ICityFileRead cityFileRead, IWeatherAPIExternal weatherAPIExternal, ICityFileWrite cityFileWrite)
        {
            _cityFileRead = cityFileRead;
            _weatherAPIExternal = weatherAPIExternal;
            _cityFileWrite = cityFileWrite;
        }
        public async Task<IEnumerable<CityDto>> GetWeatherInformationForCities(string cities)
        {
            try
            {
                //Split the file text into a list
                IEnumerable<string> citySearchWeatherList = cities.Trim().Split("\r\n").ToList();
                IEnumerable<CityDto>? cityMasterList;

                //Get city master identifiers from the dummy file
                cityMasterList = _cityFileRead.GetCityMasterList();

                var cityWeatherResult = (from cm in cityMasterList
                                         join csw in citySearchWeatherList
                                         on cm.name equals csw
                                         select new CityDto { name = csw, id = cm.id }).ToList();


                //Call the external weather application
                foreach (var city in cityWeatherResult)
                {

                    var weatherInformation = await _weatherAPIExternal.GetCityWeatherInformation(city.id);
                    if (weatherInformation != null)
                    {
                        city.weatherinformation = weatherInformation;
                    }

                    //Generate & store file in output folder for each city
                    _cityFileWrite.WriteCityFile(city);
                }

                return cityWeatherResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
