﻿namespace MandG_WeatherApplication_Middleware.Dtos
{
    public class CityDto
    {
        public string id { get; set; }

        public string name { get; set; }

        public string weatherinformation { get; set; }
    }
}
