﻿using MandG_WeatherApplication_Middleware.Dtos;
using MandG_WeatherApplication_Middleware.Interfaces;
using Newtonsoft.Json;
using System.Text;

namespace MandG_WeatherApplication_Middleware
{
    public class CityFileWrite : ICityFileWrite
    {
        public void WriteCityFile(CityDto cityDto)
        {
            try
            {
                string folderPathDirectory = "Output";
                string filePath = Path.Combine(Directory.GetCurrentDirectory(), folderPathDirectory);
                string filename = cityDto.name + "_" + DateTime.Today.ToString("dd-MM-yyyy") + ".json";

                CreateDirectory(filePath);

                using (var fileStream = System.IO.File.Create(filePath + "\\" + filename))
                {
                    var bytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(cityDto));
                    fileStream.Write(bytes);
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }


        public void CreateDirectory(string filePath)
        {
            if (!Directory.Exists(filePath))
                Directory.CreateDirectory(filePath);
        }
    }
}
