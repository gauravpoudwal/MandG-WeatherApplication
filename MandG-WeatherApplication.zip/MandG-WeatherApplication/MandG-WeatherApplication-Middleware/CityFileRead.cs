﻿using MandG_WeatherApplication_Middleware.Dtos;
using MandG_WeatherApplication_Middleware.Interfaces;
using Newtonsoft.Json;

namespace MandG_WeatherApplication_Middleware
{
    public class CityFileRead : ICityFileRead
    {
        public IEnumerable<CityDto> GetCityMasterList()
        {
            IEnumerable<CityDto> cityDtos;
            try
            {
                using (var cityInformationReader = new StreamReader("Input\\city.list.json"))
                {
                    var cityMasterOutput = cityInformationReader.ReadToEnd();
                    cityDtos = JsonConvert.DeserializeObject<IEnumerable<CityDto>>(cityMasterOutput);
                }

                return cityDtos;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
