﻿using MandG_WeatherApplication_Middleware.Dtos;

namespace MandG_WeatherApplication_Middleware.Interfaces
{
    public interface IWeatherInformationMiddleware
    {
        public Task<IEnumerable<CityDto>> GetWeatherInformationForCities(string cities);
    }
}
