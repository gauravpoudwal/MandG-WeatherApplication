﻿using MandG_WeatherApplication_Middleware.Dtos;

namespace MandG_WeatherApplication_Middleware.Interfaces
{
    public interface ICityFileRead
    {
        public IEnumerable<CityDto> GetCityMasterList();

    }
}
