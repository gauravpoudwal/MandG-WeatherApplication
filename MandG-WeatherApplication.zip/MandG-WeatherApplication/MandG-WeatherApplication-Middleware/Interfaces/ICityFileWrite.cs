﻿using MandG_WeatherApplication_Middleware.Dtos;

namespace MandG_WeatherApplication_Middleware.Interfaces
{
    public interface ICityFileWrite
    {
        public void WriteCityFile(CityDto cityDto);
    }
}
