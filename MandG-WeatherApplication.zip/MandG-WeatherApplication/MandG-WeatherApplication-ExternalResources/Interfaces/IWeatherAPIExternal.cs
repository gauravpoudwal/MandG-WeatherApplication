﻿namespace MandG_WeatherApplication_ExternalResources.Interfaces
{
    public interface IWeatherAPIExternal
    {
        public Task<string> GetCityWeatherInformation(string cityId);
    }
}
