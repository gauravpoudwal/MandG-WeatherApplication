﻿using MandG_WeatherApplication_ExternalResources.Interfaces;
using MandG_WeatherApplication_ExternalResources.Models.Responses;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace MandG_WeatherApplication_ExternalResources
{
    public class WeatherAPIExternal : IWeatherAPIExternal
    {
        private readonly IConfiguration _configuration;
        public WeatherAPIExternal(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public async Task<string> GetCityWeatherInformation(string cityId)
        {
            try
            {
                WeatherAPIResponse response;

                var hostname = _configuration["WeatherAPI:Hostname"];
                var url = _configuration["WeatherAPI:Url"];
                var appId = _configuration["WeatherAPI:ApplicationId"];
                HttpClient httpClient = new HttpClient();
                httpClient.BaseAddress = new Uri(hostname);

                var responseMessage = await httpClient.GetAsync(url + "?id=" + cityId + "&appid=" + appId);
                if (responseMessage.IsSuccessStatusCode)
                {
                    var responseString = await responseMessage.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<WeatherAPIResponse>(responseString);
                    return result?.weather.FirstOrDefault()?.main + " - " + result?.weather.FirstOrDefault()?.description;
                }
                else
                {
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
